﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ders_04_02_Yapicilar
{
    public class Kutu
    {
        private double uzunluk;
        private double genislik;
        private double yukseklik;

        //constructor veya yapıcı
        public Kutu(double u, double g, double y)
        {
            set_uzunluk(u);
            set_genislik(g);
            set_yukseklik(y);
        }

        ~Kutu()
        {
            Console.WriteLine("Nesne ölüyor.");
        }

        #region Boyutları Ayarlama
        public void set_uzunluk(double u)
        {
            if (u <= 0)
                uzunluk = 1;
            else
                uzunluk = u;
        }

        public void set_genislik(double g)
        {
            if (g <= 0)
                genislik = 1;
            else
                genislik = g;
        }

        public void set_yukseklik(double h)
        {
            if (h <= 0)
                yukseklik = 1;
            else
                yukseklik = h;
        }
        #endregion

        #region Boyutları Okuma
        public double get_uzunluk()
        {
            return uzunluk;
        }

        public double get_yukseklik()
        {
            return yukseklik;
        }

        public double get_genislik()
        {
            return genislik;
        }
        #endregion

        public double hacmi_hesapla()
        {
            return yukseklik * uzunluk * genislik;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Kutu _nesne1 = new Kutu(9.2, 6.5, -1);
            Kutu _nesne2 = new Kutu(1.2, 2.5, 5.6);

            Console.WriteLine("Nesne 1 hacmi: " + _nesne1.hacmi_hesapla());
            Console.WriteLine("Nesne 2 hacmi: " + _nesne2.hacmi_hesapla());
            Console.WriteLine("Nesne 1: " + _nesne1.get_uzunluk() + " " + _nesne1.get_genislik() + " " + _nesne1.get_yukseklik());
            Console.WriteLine("Nesne 2: " + _nesne2.get_uzunluk() + " " + _nesne2.get_genislik() + " " + _nesne2.get_yukseklik());

            _nesne1 = null;
            _nesne2 = null;
            GC.Collect();

            Console.ReadKey();
        }
    }
}
