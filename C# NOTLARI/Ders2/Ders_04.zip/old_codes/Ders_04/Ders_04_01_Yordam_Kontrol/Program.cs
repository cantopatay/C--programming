﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ders_04_01_Yordam_Kontrol
{
    public class Kutu
    {
        private double uzunluk;
        private double genislik;
        private double yukseklik;

        #region Boyutları Ayarlama
        public void set_uzunluk(double u)
        {
            if (u <= 0)
                uzunluk = 1;
            else
                uzunluk = u;
        }

        public void set_genislik(double g)
        {
            if (g <= 0)
                genislik = 1;
            else
                genislik = g;
        }

        public void set_yukseklik(double h)
        {
            if (h <= 0)
                yukseklik = 1;
            else
                yukseklik = h;
        }
        #endregion

        #region Boyutları Okuma
        public double get_uzunluk()
        {
            return uzunluk;
        }

        public double get_yukseklik()
        {
            return yukseklik;
        }

        public double get_genislik()
        {
            return genislik;
        }
        #endregion

        public double hacmi_hesapla()
        {
            return yukseklik * uzunluk * genislik; 
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Kutu _nesne1 = new Kutu();
            //_nesne1.uzunluk = 9.2;
            //_nesne1.yukseklik = -1; //istenmeyen durum
            //_nesne1.genislik = 6.5; //private değişkenlere veya metotlara dışarıdan ulaşım yapılamaz.
            _nesne1.set_uzunluk(9.2);
            _nesne1.set_genislik(6.5);
            _nesne1.set_yukseklik(-1);

            Kutu _nesne2 = new Kutu();
            _nesne2.set_uzunluk(1.2);
            _nesne2.set_genislik(2.5);
            _nesne2.set_yukseklik(5.6);
           
            Console.WriteLine("Nesne 1 hacmi: " + _nesne1.hacmi_hesapla());
            Console.WriteLine("Nesne 2 hacmi: " + _nesne2.hacmi_hesapla());
            Console.WriteLine("Nesne 1: " + _nesne1.get_uzunluk() + " " + _nesne1.get_genislik() + " " +_nesne1.get_yukseklik());
            Console.WriteLine("Nesne 2: " + _nesne2.get_uzunluk() + " " + _nesne2.get_genislik() + " " + _nesne2.get_yukseklik());
            
            Console.ReadKey();
        }
    }
}
