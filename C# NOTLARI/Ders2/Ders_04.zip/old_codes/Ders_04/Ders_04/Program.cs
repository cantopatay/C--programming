﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ders_04
{
    public class Kutu
    {
        public double uzunluk;
        public double genislik;
        public double yukseklik;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Kutu _nesne1 = new Kutu();
            _nesne1.uzunluk = 9.2;
            _nesne1.yukseklik = 4.5;
            _nesne1.genislik = 6.5;

            Kutu _nesne2 = new Kutu();
            _nesne2.uzunluk = 1.2;
            _nesne2.yukseklik = 3.4;
            _nesne2.genislik = 2.5;

            Console.WriteLine("Nesne 1 hacmi: " + _nesne1.genislik * _nesne1.uzunluk * _nesne1.yukseklik);            
            Console.WriteLine("Nesne 2 hacmi: " + _nesne2.genislik * _nesne2.uzunluk * _nesne2.yukseklik);
            Console.ReadKey();
        }
    }
}
