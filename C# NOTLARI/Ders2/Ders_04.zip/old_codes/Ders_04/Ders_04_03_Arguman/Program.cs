﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ders_04_03_Arguman
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach (string item in args)
                Console.WriteLine(item);

            Console.ReadKey();
        }
    }
}
