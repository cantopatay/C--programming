﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders04_02_Class_Object
{
    class Daire
    {
        public int yaricap;

        public double DaireCevresi() 
        {
            return 2 * 3.14 * yaricap;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Daire _d_nesne_01 = new Daire();
            _d_nesne_01.yaricap = 5;
            double cevre = _d_nesne_01.DaireCevresi();

            Console.WriteLine("Yarıçap: " + _d_nesne_01.yaricap);
            Console.WriteLine("Daire çevresi: " + cevre);

            Daire _d_nesne_02 = new Daire();
            _d_nesne_02.yaricap = 15;

            Console.WriteLine("Yarıçap: " + _d_nesne_02.yaricap);
            Console.WriteLine("Daire çevresi: " + _d_nesne_02.DaireCevresi());

            Console.ReadLine();
        }
    }
}
