﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders04_01_Class_Object
{
    class Daire
    {
        public int yaricap;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Daire _d_nesne_01 = new Daire();
            _d_nesne_01.yaricap = 15;

            Console.WriteLine(_d_nesne_01.yaricap);

            Daire _d_nesne_02 = new Daire();
            _d_nesne_02.yaricap = 5;

            Console.WriteLine(_d_nesne_02.yaricap);

            Console.ReadLine();
        }
    }
}
