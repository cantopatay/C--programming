﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders04_08_Constructor
{
    //Sınıf
    public class Daire
    {
        public int yaricap;

        //Yapıcı veya Constructor
        public Daire(int r)
        {
            yaricap = r;
        }

        ~Daire()
        {
            Console.WriteLine("Yıkıcı Çağrıldı");
        }
       
        public double CevreHesapla()
        {
            return 2 * 3.14 * yaricap;
        }

        public double AlanHesapla()
        {
            return 3.14 * yaricap * yaricap;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Daire _daire = new Daire(5);
            Console.WriteLine(_daire.yaricap);
            Console.WriteLine(_daire.CevreHesapla());
            Console.WriteLine(_daire.AlanHesapla());
            Console.ReadLine();
        }
    }
}
