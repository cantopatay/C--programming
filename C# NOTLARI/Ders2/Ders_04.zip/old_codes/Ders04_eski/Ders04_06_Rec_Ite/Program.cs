﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders04_06_Rec_Ite
{
    class Matematik
    {
        public int faktoriyel_iterasyon(int sayi)
        {
            int temp = 1;
            for (int i = sayi; i > 0; i--)
            {
                temp *= i;
            }

            return temp;
        }

        public int faktoriyel_recursive(int sayi)
        {
            if (sayi <= 1)
                return 1;
            else
                return sayi * faktoriyel_recursive(sayi - 1);
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Matematik _m = new Matematik();
            int sonuc01 = _m.faktoriyel_iterasyon(5);
            int sonuc02 = _m.faktoriyel_recursive(6);

            Console.WriteLine(sonuc01);
            Console.WriteLine(sonuc02);
            Console.ReadLine();
        }
    }
}
