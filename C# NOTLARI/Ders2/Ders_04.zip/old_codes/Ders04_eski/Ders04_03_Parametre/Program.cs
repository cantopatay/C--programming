﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders04_03_Parametre
{
    class Daire
    {
        public double DaireCevresi(int yaricap)
        {
            return 2 * 3.14 * yaricap;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Daire _d_nesne = new Daire();
            double cevre = _d_nesne.DaireCevresi(5);

            Console.WriteLine("Daire çevresi: " + cevre);
            Console.ReadLine();
        }
    }
}
