﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders04_04_Ref
{
    class Matematik
    {
        public void arttirma_01(int x) 
        {
            x++;
        }

        public void arttirma_02(ref int x)
        {
            x++;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Matematik _m = new Matematik();
            int sayi = 5;
            _m.arttirma_01(sayi);

            Console.WriteLine(sayi);

            _m.arttirma_02(ref sayi);

            Console.WriteLine(sayi);

            Console.ReadLine();
        }
    }
}
