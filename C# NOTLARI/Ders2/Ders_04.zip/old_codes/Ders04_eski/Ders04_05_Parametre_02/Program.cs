﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders04_05_Parametre_02
{
    class islem
    {
        public double ortalama_al(int[] sayilar) 
        {
            int toplam = 0;
            foreach (int sayi in sayilar)
                toplam += sayi;

            return (double)toplam / sayilar.Length;
        }

        public int[] dizi_toplami(int[] dizi01, int[] dizi02)
        {
            int[] _dizi = new int[dizi01.Length];

            for (int i = 0; i < dizi01.Length; i++)
                _dizi[i] = dizi01[i] + dizi02[i];

            return _dizi;
        }
 
    }

    class Program
    {
        static void Main(string[] args)
        {
            int[] Degerler = { 5, 10, 12, 14, 100, 100 };
            int[] Degerler2 = { 15, 110, 112, 114, 1100, 1100 };

            islem _i = new islem();
            double _ort = _i.ortalama_al(Degerler);
            Console.WriteLine(_ort);

            int[] _sonuclar = _i.dizi_toplami(Degerler, Degerler2);
            foreach (int _s in _sonuclar)
                Console.WriteLine(_s);
            Console.ReadLine();
        }
    }
}
