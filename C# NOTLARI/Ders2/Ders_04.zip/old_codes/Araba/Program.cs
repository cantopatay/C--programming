﻿using System;

namespace Araba
{
    public class araba{
        private double yakit;
        private int hiz;

        public araba(double y, int s){
            set_Yakit(y);
            set_Hiz(s);
        }

        public string goster(){
            return "Yakıt miktarı: " + yakit.ToString() + " - Hız: " + hiz.ToString();
        }

        public void set_Yakit(double y){
            if (y > 60)
               y = 60;
            if (y < 0)
               y = 0;
            yakit = y;
        }

        public double get_Yakit(){
            return yakit;
        }

        public void set_Hiz(int s){
            if (s > 260)
               s = 260;
            if (s < 0)
               s = 40;
            hiz = s;
        }

        public int get_Hiz(){
            return hiz;
        }

        public void Yakit_Yukle(double y){
            y = yakit + y;
            set_Yakit(y);
        }

        public void sur(){
            if (hiz < 50)
               yakit -= 3;
            else if(hiz < 90)
               yakit -= 1;
            else if(hiz < 140)
               yakit -= 2;
            else if(hiz < 180)
               yakit -= 3;
            else
               yakit -= 4;

            set_Yakit(yakit);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            araba nesne01 = new araba(35, 20);
            Console.WriteLine(nesne01.goster());
            nesne01.sur();
            Console.WriteLine(nesne01.goster());
            nesne01.set_Hiz(80);
            nesne01.sur();
            Console.WriteLine(nesne01.goster());
            nesne01.set_Hiz(120);
            nesne01.sur();
            Console.WriteLine(nesne01.goster());
            nesne01.set_Hiz(220);
            nesne01.sur();
            Console.WriteLine(nesne01.goster());

            Console.WriteLine("------------------------");
            
            araba nesne02 = new araba(10, 120);
            Console.WriteLine(nesne01.goster());
            nesne01.sur();
            Console.WriteLine(nesne01.goster());
            nesne01.set_Hiz(180);
            nesne01.sur();
            Console.WriteLine(nesne01.goster());
            nesne01.set_Hiz(220);
            nesne01.sur();
            Console.WriteLine(nesne01.goster());
            nesne01.set_Hiz(260);
            nesne01.sur();
            Console.WriteLine(nesne01.goster());
        }
    }
}
