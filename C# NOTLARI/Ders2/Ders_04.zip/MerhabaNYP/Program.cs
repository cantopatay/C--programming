﻿using System;

namespace MerhabaNYP
{
    public class kutu{
        public int x;
        public int y;
        public int z;

        public int hacmi_hesapla(){
            return x * y * z;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            kutu k01 = new kutu();
            k01.x = 10;
            k01.y = 20;
            k01.z = 5;

            //Console.WriteLine("Hacmi: " + (k01.x * k01.y * k01.z));
            Console.WriteLine("Hacmi: " + k01.hacmi_hesapla());

            kutu k02 = new kutu();
            k02.x = 8;
            k02.y = 3;
            k02.z = 5;

            // Console.WriteLine("Hacmi: " + (k02.x * k02.y * k02.z));
            Console.WriteLine("Hacmi: " + k02.hacmi_hesapla());
        }
    }
}
